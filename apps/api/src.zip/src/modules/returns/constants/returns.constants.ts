export const RETURNS_CONSTANTS = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 20,
  MAX_LIMIT: 100,

  RETURN_NUMBER_PREFIX: 'RTN',

  SLA: {
    REVIEW_HOURS: 24,
    APPROVAL_HOURS: 48,
    RESOLUTION_HOURS: 72,
    AUTO_CLOSE_DAYS: 30,
  },

  QUEUES: {
    RETURN_PROCESSING: 'return-processing',
    AI_ANALYSIS: 'return-ai-analysis',
    MARKETPLACE_SYNC: 'return-marketplace-sync',
    NOTIFICATIONS: 'return-notifications',
  },

  RETRY: {
    MAX_ATTEMPTS: 3,
    BACKOFF_MS: 5000,
  },

  AI: {
    MIN_CONFIDENCE: 0.75,
    HIGH_CONFIDENCE: 0.9,
  },

  ATTACHMENTS: {
    MAX_FILES: 20,
    MAX_FILE_SIZE_MB: 100,
    ALLOWED_TYPES: [
      'image/jpeg',
      'image/png',
      'image/webp',
      'video/mp4',
      'application/pdf',
    ],
  },

  MARKETPLACES: {
    AMAZON: 'AMAZON',
    FLIPKART: 'FLIPKART',
    MEESHO: 'MEESHO',
    SHOPIFY: 'SHOPIFY',
    WOOCOMMERCE: 'WOOCOMMERCE',
    MANUAL: 'MANUAL',
  },

  PRIORITY: {
    LOW: 'LOW',
    MEDIUM: 'MEDIUM',
    HIGH: 'HIGH',
    CRITICAL: 'CRITICAL',
  },

  STATUS: {
    DRAFT: 'DRAFT',
    CREATED: 'CREATED',
    UNDER_REVIEW: 'UNDER_REVIEW',
    AI_ANALYZING: 'AI_ANALYZING',
    WAITING_FOR_EVIDENCE: 'WAITING_FOR_EVIDENCE',
    APPROVED: 'APPROVED',
    REJECTED: 'REJECTED',
    REFUNDED: 'REFUNDED',
    REPLACED: 'REPLACED',
    CLOSED: 'CLOSED',
    CANCELLED: 'CANCELLED',
  },

  AUDIT_EVENTS: {
    CREATED: 'RETURN_CREATED',
    UPDATED: 'RETURN_UPDATED',
    ASSIGNED: 'RETURN_ASSIGNED',
    AI_STARTED: 'RETURN_AI_STARTED',
    AI_COMPLETED: 'RETURN_AI_COMPLETED',
    APPROVED: 'RETURN_APPROVED',
    REJECTED: 'RETURN_REJECTED',
    REFUNDED: 'RETURN_REFUNDED',
    REPLACED: 'RETURN_REPLACED',
    CLOSED: 'RETURN_CLOSED',
    CANCELLED: 'RETURN_CANCELLED',
  },
} as const;
