import { Injectable } from '@nestjs/common';

import { StorageFactory } from './storage.factory';

import {
  ChunkUploadResult,
  CompletedMultipartUpload,
  PresignedUrlResult,
  UploadMetadata,
  UploadResult,
  UploadSession,
} from '../types/upload.types';

@Injectable()
export class StorageService {
  constructor(private readonly storageFactory: StorageFactory) {}

  async upload(
    key: string,
    buffer: Buffer,
    mimeType: string,
    metadata?: UploadMetadata,
  ): Promise<UploadResult> {
    return this.storageFactory
      .getProvider()
      .upload(key, buffer, mimeType, metadata);
  }

  async delete(key: string): Promise<void> {
    return this.storageFactory.getProvider().delete(key);
  }

  async exists(key: string): Promise<boolean> {
    return this.storageFactory.getProvider().exists(key);
  }

  async getUrl(key: string): Promise<string> {
    return this.storageFactory.getProvider().getUrl(key);
  }

  async generateUploadUrl(
    key: string,
    expiresIn?: number,
  ): Promise<PresignedUrlResult> {
    return this.storageFactory.getProvider().generateUploadUrl(key, expiresIn);
  }

  async generateDownloadUrl(
    key: string,
    expiresIn?: number,
  ): Promise<PresignedUrlResult> {
    return this.storageFactory
      .getProvider()
      .generateDownloadUrl(key, expiresIn);
  }

  async initiateMultipartUpload(
    key: string,
    mimeType: string,
    metadata?: UploadMetadata,
  ): Promise<UploadSession> {
    return this.storageFactory
      .getProvider()
      .initiateMultipartUpload(key, mimeType, metadata);
  }

  async uploadPart(
    uploadId: string,
    key: string,
    partNumber: number,
    buffer: Buffer,
  ): Promise<ChunkUploadResult> {
    return this.storageFactory
      .getProvider()
      .uploadPart(uploadId, key, partNumber, buffer);
  }

  async completeMultipartUpload(
    uploadId: string,
    key: string,
    parts: ChunkUploadResult[],
  ): Promise<CompletedMultipartUpload> {
    return this.storageFactory
      .getProvider()
      .completeMultipartUpload(uploadId, key, parts);
  }

  async abortMultipartUpload(uploadId: string, key: string): Promise<void> {
    return this.storageFactory
      .getProvider()
      .abortMultipartUpload(uploadId, key);
  }
}
