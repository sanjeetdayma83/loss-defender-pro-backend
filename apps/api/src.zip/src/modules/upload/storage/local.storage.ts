import { Injectable, NotImplementedException } from '@nestjs/common';

import { StorageInterface } from './storage.interface';

import {
  ChunkUploadResult,
  CompletedMultipartUpload,
  PresignedUrlResult,
  UploadMetadata,
  UploadResult,
  UploadSession,
} from '../types/upload.types';

@Injectable()
export class LocalStorage implements StorageInterface {
  readonly provider = 'local' as const;

  upload(
    key: string,
    buffer: Buffer,
    mimeType: string,
    metadata?: UploadMetadata,
  ): Promise<UploadResult> {
    void key;
    void buffer;
    void mimeType;
    void metadata;
    return Promise.reject(
      new NotImplementedException('Local storage upload not implemented.'),
    );
  }

  delete(key: string): Promise<void> {
    void key;
    return Promise.reject(
      new NotImplementedException('Local storage delete not implemented.'),
    );
  }

  exists(key: string): Promise<boolean> {
    void key;
    return Promise.reject(
      new NotImplementedException('Local storage exists not implemented.'),
    );
  }

  getUrl(key: string): Promise<string> {
    void key;
    return Promise.reject(
      new NotImplementedException(
        'Local storage URL generation not implemented.',
      ),
    );
  }

  generateUploadUrl(
    key: string,
    expiresIn = 3600,
  ): Promise<PresignedUrlResult> {
    void key;
    void expiresIn;
    return Promise.reject(
      new NotImplementedException('Local upload URL not implemented.'),
    );
  }

  generateDownloadUrl(
    key: string,
    expiresIn = 3600,
  ): Promise<PresignedUrlResult> {
    void key;
    void expiresIn;
    return Promise.reject(
      new NotImplementedException('Local download URL not implemented.'),
    );
  }

  initiateMultipartUpload(
    key: string,
    mimeType: string,
    metadata?: UploadMetadata,
  ): Promise<UploadSession> {
    void key;
    void mimeType;
    void metadata;
    return Promise.reject(
      new NotImplementedException('Multipart upload not implemented.'),
    );
  }

  uploadPart(
    uploadId: string,
    key: string,
    partNumber: number,
    buffer: Buffer,
  ): Promise<ChunkUploadResult> {
    void uploadId;
    void key;
    void partNumber;
    void buffer;
    return Promise.reject(
      new NotImplementedException('Upload part not implemented.'),
    );
  }

  completeMultipartUpload(
    uploadId: string,
    key: string,
    parts: ChunkUploadResult[],
  ): Promise<CompletedMultipartUpload> {
    void uploadId;
    void key;
    void parts;
    return Promise.reject(
      new NotImplementedException('Complete multipart upload not implemented.'),
    );
  }

  abortMultipartUpload(uploadId: string, key: string): Promise<void> {
    void uploadId;
    void key;
    return Promise.reject(
      new NotImplementedException('Abort multipart upload not implemented.'),
    );
  }
}
