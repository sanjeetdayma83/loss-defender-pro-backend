import { Injectable, NotImplementedException } from '@nestjs/common';

import { StorageInterface } from './storage.interface';

import {
  ChunkUploadResult,
  CompletedMultipartUpload,
  PresignedUrlResult,
  UploadMetadata,
  UploadResult,
  UploadSession,
} from '../types/upload.types';

@Injectable()
export class MinioStorage implements StorageInterface {
  readonly provider = 'minio' as const;

  upload(
    key: string,
    buffer: Buffer,
    mimeType: string,
    metadata?: UploadMetadata,
  ): Promise<UploadResult> {
    void key;
    void buffer;
    void mimeType;
    void metadata;
    return Promise.reject(
      new NotImplementedException('MinIO upload not implemented.'),
    );
  }

  delete(key: string): Promise<void> {
    void key;
    return Promise.reject(
      new NotImplementedException('MinIO delete not implemented.'),
    );
  }

  exists(key: string): Promise<boolean> {
    void key;
    return Promise.reject(
      new NotImplementedException('MinIO exists not implemented.'),
    );
  }

  getUrl(key: string): Promise<string> {
    void key;
    return Promise.reject(
      new NotImplementedException('MinIO URL generation not implemented.'),
    );
  }

  generateUploadUrl(
    key: string,
    expiresIn = 3600,
  ): Promise<PresignedUrlResult> {
    void key;
    void expiresIn;
    return Promise.reject(
      new NotImplementedException(
        'MinIO presigned upload URL not implemented.',
      ),
    );
  }

  generateDownloadUrl(
    key: string,
    expiresIn = 3600,
  ): Promise<PresignedUrlResult> {
    void key;
    void expiresIn;
    return Promise.reject(
      new NotImplementedException(
        'MinIO presigned download URL not implemented.',
      ),
    );
  }

  initiateMultipartUpload(
    key: string,
    mimeType: string,
    metadata?: UploadMetadata,
  ): Promise<UploadSession> {
    void key;
    void mimeType;
    void metadata;
    return Promise.reject(
      new NotImplementedException('MinIO multipart upload not implemented.'),
    );
  }

  uploadPart(
    uploadId: string,
    key: string,
    partNumber: number,
    buffer: Buffer,
  ): Promise<ChunkUploadResult> {
    void uploadId;
    void key;
    void partNumber;
    void buffer;
    return Promise.reject(
      new NotImplementedException('MinIO upload part not implemented.'),
    );
  }

  completeMultipartUpload(
    uploadId: string,
    key: string,
    parts: ChunkUploadResult[],
  ): Promise<CompletedMultipartUpload> {
    void uploadId;
    void key;
    void parts;
    return Promise.reject(
      new NotImplementedException(
        'MinIO complete multipart upload not implemented.',
      ),
    );
  }

  abortMultipartUpload(uploadId: string, key: string): Promise<void> {
    void uploadId;
    void key;
    return Promise.reject(
      new NotImplementedException(
        'MinIO abort multipart upload not implemented.',
      ),
    );
  }
}
