import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

import { StorageProvider } from '../types/upload.types';

import { StorageInterface } from './storage.interface';
import { LocalStorage } from './local.storage';
import { S3Storage } from './s3.storage';
import { MinioStorage } from './minio.storage';

@Injectable()
export class StorageFactory {
  constructor(
    private readonly configService: ConfigService,
    private readonly localStorage: LocalStorage,
    private readonly s3Storage: S3Storage,
    private readonly minioStorage: MinioStorage,
  ) {}

  getProvider(): StorageInterface {
    const provider = this.configService.get<StorageProvider>(
      'STORAGE_PROVIDER',
      'local',
    );

    switch (provider) {
      case 'local':
        return this.localStorage;

      case 's3':
        return this.s3Storage;

      case 'minio':
        return this.minioStorage;

      default:
        throw new InternalServerErrorException(
          `Unsupported storage provider: ${String(provider)}`,
        );
    }
  }

  getProviderByName(provider: StorageProvider): StorageInterface {
    switch (provider) {
      case 'local':
        return this.localStorage;

      case 's3':
        return this.s3Storage;

      case 'minio':
        return this.minioStorage;

      default:
        throw new InternalServerErrorException(
          `Unsupported storage provider: ${String(provider)}`,
        );
    }
  }
}
