import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class TokenStorage {
  TokenStorage._();

  static const FlutterSecureStorage _storage = FlutterSecureStorage();

  static const String _accessToken = 'access_token';
  static const String _refreshToken = 'refresh_token';

  /// Keeps compatibility with existing code
  static Future<void> save({
    required String accessToken,
    required String refreshToken,
  }) async {
    await _storage.write(key: _accessToken, value: accessToken);

    await _storage.write(key: _refreshToken, value: refreshToken);
  }

  static Future<String?> accessToken() async {
    return _storage.read(key: _accessToken);
  }

  static Future<String?> refreshToken() async {
    return _storage.read(key: _refreshToken);
  }

  static Future<void> clear() async {
    await _storage.deleteAll();
  }

  static Future<bool> isLoggedIn() async {
    final token = await accessToken();
    return token != null && token.isNotEmpty;
  }
}
