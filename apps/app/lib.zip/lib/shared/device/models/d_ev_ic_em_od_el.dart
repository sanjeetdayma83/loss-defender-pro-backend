class DeviceModel {
  const DeviceModel();
}
