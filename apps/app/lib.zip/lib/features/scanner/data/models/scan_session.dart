class ScanSession {
  final String? lastBarcode;
  final DateTime? lastScanTime;

  const ScanSession({this.lastBarcode, this.lastScanTime});

  bool shouldIgnore(String barcode) {
    if (lastBarcode == null || lastScanTime == null) {
      return false;
    }

    final elapsed = DateTime.now().difference(lastScanTime!);

    return lastBarcode == barcode && elapsed.inMilliseconds < 800;
  }

  ScanSession next(String barcode) {
    return ScanSession(lastBarcode: barcode, lastScanTime: DateTime.now());
  }
}
