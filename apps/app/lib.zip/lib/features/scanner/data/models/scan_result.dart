enum ScanStatus { success, duplicate, wrongSku, completed }

class ScanResult {
  final ScanStatus status;
  final String message;

  const ScanResult({required this.status, required this.message});
}
