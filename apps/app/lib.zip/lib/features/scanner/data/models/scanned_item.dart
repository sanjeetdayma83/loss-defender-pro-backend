class ScannedItem {
  final String sku;
  final String title;
  final int expectedQty;
  final int scannedQty;

  const ScannedItem({
    required this.sku,
    required this.title,
    required this.expectedQty,
    required this.scannedQty,
  });

  bool get completed => scannedQty >= expectedQty;

  ScannedItem copyWith({int? scannedQty}) {
    return ScannedItem(
      sku: sku,
      title: title,
      expectedQty: expectedQty,
      scannedQty: scannedQty ?? this.scannedQty,
    );
  }
}
