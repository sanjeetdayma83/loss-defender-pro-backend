enum ScanFeedbackType { success, duplicate, wrongSku, error }

class ScanFeedback {
  final ScanFeedbackType type;
  final String title;
  final String message;

  const ScanFeedback({
    required this.type,
    required this.title,
    required this.message,
  });

  factory ScanFeedback.success(String sku) {
    return ScanFeedback(
      type: ScanFeedbackType.success,
      title: "Verified",
      message: "$sku verified successfully",
    );
  }

  factory ScanFeedback.duplicate(String sku) {
    return ScanFeedback(
      type: ScanFeedbackType.duplicate,
      title: "Duplicate",
      message: "$sku already verified",
    );
  }

  factory ScanFeedback.wrong(String sku) {
    return ScanFeedback(
      type: ScanFeedbackType.wrongSku,
      title: "Wrong SKU",
      message: "$sku does not belong to this order",
    );
  }

  factory ScanFeedback.error(String message) {
    return ScanFeedback(
      type: ScanFeedbackType.error,
      title: "Error",
      message: message,
    );
  }
}
