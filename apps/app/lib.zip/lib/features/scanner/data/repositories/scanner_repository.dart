import '../../../../core/api/api_client.dart';

class ScannerRepository {
  Future<Map<String, dynamic>> loadOrder(String orderId) async {
    final response = await ApiClient.dio.get("/orders/$orderId");

    return response.data["data"];
  }

  Future<void> verifyScan({
    required String orderId,
    required String sku,
  }) async {
    await ApiClient.dio.post("/orders/$orderId/scan", data: {"sku": sku});
  }

  Future<void> finishVerification(String orderId) async {
    await ApiClient.dio.post("/orders/$orderId/complete-verification");
  }
}
