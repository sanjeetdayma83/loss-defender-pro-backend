import '../../../../core/api/api_client.dart';

import '../models/warehouses_model.dart';

class WarehousesRepository {
  Future<List<WarehousesModel>> getWarehouses() async {
    final response = await ApiClient.dio.get("/warehouses");

    final List items = response.data["data"];

    return items.map((e) => WarehousesModel.fromJson(e)).toList();
  }
}
