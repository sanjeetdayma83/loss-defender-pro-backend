class WarehousesModel {
  final String id;
  final String name;
  final String code;
  final String address;
  final String managerName;
  final bool active;

  const WarehousesModel({
    required this.id,
    required this.name,
    required this.code,
    required this.address,
    required this.managerName,
    required this.active,
  });

  factory WarehousesModel.fromJson(Map<String, dynamic> json) {
    return WarehousesModel(
      id: json["id"] ?? "",
      name: json["name"] ?? "",
      code: json["code"] ?? "",
      address: json["address"] ?? "",
      managerName: json["managerName"] ?? "",
      active: json["active"] ?? false,
    );
  }
}
