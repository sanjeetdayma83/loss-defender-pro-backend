class DeviceModel {}
