class DeviceRepository {}
