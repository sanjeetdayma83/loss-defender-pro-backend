class DeviceProvider {}
