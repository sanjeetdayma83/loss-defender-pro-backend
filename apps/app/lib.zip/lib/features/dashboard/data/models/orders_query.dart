class OrdersQuery {
  final int page;
  final int limit;
  final String search;
  final String? marketplace;
  final String? status;
  final String? priority;

  const OrdersQuery({
    this.page = 1,
    this.limit = 20,
    this.search = "",
    this.marketplace,
    this.status,
    this.priority,
  });

  Map<String, dynamic> toQuery() {
    return {
      "page": page,
      "limit": limit,
      if (search.isNotEmpty) "search": search,
      if (marketplace != null && marketplace!.isNotEmpty)
        "marketplace": marketplace,
      if (status != null && status!.isNotEmpty) "status": status,
      if (priority != null && priority!.isNotEmpty) "priority": priority,
    };
  }

  OrdersQuery copyWith({
    int? page,
    int? limit,
    String? search,
    String? marketplace,
    String? status,
    String? priority,
  }) {
    return OrdersQuery(
      page: page ?? this.page,
      limit: limit ?? this.limit,
      search: search ?? this.search,
      marketplace: marketplace ?? this.marketplace,
      status: status ?? this.status,
      priority: priority ?? this.priority,
    );
  }
}
