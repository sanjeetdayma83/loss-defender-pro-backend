import 'dashboard_summary.dart';

class DashboardModel {
  final DashboardSummary summary;

  const DashboardModel({required this.summary});

  factory DashboardModel.fromJson(Map<String, dynamic> json) {
    return DashboardModel(summary: DashboardSummary.fromJson(json));
  }

  Map<String, dynamic> toJson() {
    return {
      "summary": {
        "totalOrders": summary.totalOrders,
        "todayOrders": summary.todayOrders,
        "packing": summary.packing,
        "verification": summary.verification,
        "readyToShip": summary.readyToShip,
      },
    };
  }
}
