class DashboardSummary {
  final int totalOrders;
  final int todayOrders;
  final int packing;
  final int verification;
  final int readyToShip;

  const DashboardSummary({
    required this.totalOrders,
    required this.todayOrders,
    required this.packing,
    required this.verification,
    required this.readyToShip,
  });

  factory DashboardSummary.fromJson(Map<String, dynamic> json) {
    final stats = (json['statistics'] as Map<String, dynamic>? ?? {});

    return DashboardSummary(
      totalOrders: (stats['total'] ?? 0) as int,
      todayOrders: (json['todayOrders'] ?? 0) as int,
      packing: (stats['packing'] ?? 0) as int,
      verification: (stats['verifying'] ?? 0) as int,
      readyToShip: (stats['readyToShip'] ?? 0) as int,
    );
  }
}
