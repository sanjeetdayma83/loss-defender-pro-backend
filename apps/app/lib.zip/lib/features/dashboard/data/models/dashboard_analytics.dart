class DashboardAnalytics {
  final List<DailyTrend> dailyTrend;
  final List<MarketplaceAnalytics> marketplace;
  final List<StatusAnalytics> status;

  const DashboardAnalytics({
    required this.dailyTrend,
    required this.marketplace,
    required this.status,
  });
}

class DailyTrend {
  final String date;
  final int total;

  const DailyTrend({required this.date, required this.total});

  factory DailyTrend.fromJson(Map<String, dynamic> json) {
    return DailyTrend(date: json["date"] ?? "", total: json["total"] ?? 0);
  }
}

class MarketplaceAnalytics {
  final String marketplace;
  final int total;

  const MarketplaceAnalytics({required this.marketplace, required this.total});

  factory MarketplaceAnalytics.fromJson(Map<String, dynamic> json) {
    return MarketplaceAnalytics(
      marketplace: json["marketplace"] ?? "",
      total: json["total"] ?? 0,
    );
  }
}

class StatusAnalytics {
  final String status;
  final int total;

  const StatusAnalytics({required this.status, required this.total});

  factory StatusAnalytics.fromJson(Map<String, dynamic> json) {
    return StatusAnalytics(
      status: json["status"] ?? "",
      total: json["total"] ?? 0,
    );
  }
}
