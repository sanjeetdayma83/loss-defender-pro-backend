class RecentOrderModel {
  final String id;
  final String orderNumber;
  final String customerName;
  final String marketplace;
  final String status;
  final String priority;
  final DateTime createdAt;

  const RecentOrderModel({
    required this.id,
    required this.orderNumber,
    required this.customerName,
    required this.marketplace,
    required this.status,
    required this.priority,
    required this.createdAt,
  });

  factory RecentOrderModel.fromJson(Map<String, dynamic> json) {
    return RecentOrderModel(
      id: json["id"] ?? "",
      orderNumber: json["orderNumber"] ?? "",
      customerName: json["customerName"] ?? "",
      marketplace: json["marketplace"] ?? "",
      status: json["status"] ?? "",
      priority: json["priority"] ?? "",
      createdAt: DateTime.parse(json["createdAt"]),
    );
  }
}
