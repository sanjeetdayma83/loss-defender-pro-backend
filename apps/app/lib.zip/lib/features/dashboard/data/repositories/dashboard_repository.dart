import '../../../../core/api/api_client.dart';

import '../models/dashboard_summary.dart';
import '../models/recent_order_model.dart';
import '../models/dashboard_analytics.dart';

class DashboardRepository {
  Future<DashboardSummary> getDashboard() async {
    final response = await ApiClient.dio.get("/orders/dashboard");

    return DashboardSummary.fromJson(response.data["data"]);
  }

  Future<List<RecentOrderModel>> getRecentOrders() async {
    final response = await ApiClient.dio.get("/orders/recent");

    final List items = response.data["data"] as List;

    return items.map((e) => RecentOrderModel.fromJson(e)).toList();
  }

  Future<List<DailyTrend>> getDailyTrend() async {
    final response = await ApiClient.dio.get("/orders/analytics/daily-trend");

    final List list = response.data["data"];

    return list.map((e) => DailyTrend.fromJson(e)).toList();
  }

  Future<List<MarketplaceAnalytics>> getMarketplaceAnalytics() async {
    final response = await ApiClient.dio.get("/orders/analytics/marketplace");

    final List list = response.data["data"];

    return list.map((e) => MarketplaceAnalytics.fromJson(e)).toList();
  }

  Future<List<StatusAnalytics>> getStatusAnalytics() async {
    final response = await ApiClient.dio.get("/orders/analytics/status");

    final List list = response.data["data"];

    return list.map((e) => StatusAnalytics.fromJson(e)).toList();
  }
}
