import 'package:dio/dio.dart';

import '../../../../core/api/api_client.dart';
import '../../../../core/api/api_endpoints.dart';
import '../models/login_request.dart';
import '../models/login_response.dart';

class AuthRemoteDatasource {
  Future<LoginResponse> login(LoginRequest request) async {
    final Response response = await ApiClient.dio.post(
      ApiEndpoints.login,
      data: request.toJson(),
    );

    final body = response.data as Map<String, dynamic>;

    final data = body["data"] as Map<String, dynamic>;

    return LoginResponse.fromJson(data);
  }
}
