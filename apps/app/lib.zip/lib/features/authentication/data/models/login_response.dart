class LoginResponse {
  final String accessToken;
  final String refreshToken;
  final String tokenType;
  final String expiresIn;

  const LoginResponse({
    required this.accessToken,
    required this.refreshToken,
    required this.tokenType,
    required this.expiresIn,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> json) {
    return LoginResponse(
      accessToken: json["accessToken"] as String,
      refreshToken: json["refreshToken"] as String,
      tokenType: json["tokenType"] as String,
      expiresIn: json["expiresIn"] as String,
    );
  }
}
