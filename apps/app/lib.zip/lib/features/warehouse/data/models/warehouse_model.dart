class WarehouseModel {}
