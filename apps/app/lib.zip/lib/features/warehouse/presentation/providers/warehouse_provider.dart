class WarehouseProvider {}
