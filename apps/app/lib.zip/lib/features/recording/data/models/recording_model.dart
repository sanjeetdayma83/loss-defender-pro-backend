class RecordingModel {
  final String id;
  final String orderId;

  final String localPath;
  final String remoteUrl;

  final Duration duration;

  final bool uploaded;

  final DateTime createdAt;

  const RecordingModel({
    required this.id,
    required this.orderId,
    required this.localPath,
    required this.remoteUrl,
    required this.duration,
    required this.uploaded,
    required this.createdAt,
  });

  factory RecordingModel.empty() {
    return RecordingModel(
      id: '',
      orderId: '',
      localPath: '',
      remoteUrl: '',
      duration: Duration.zero,
      uploaded: false,
      createdAt: DateTime.now(),
    );
  }

  factory RecordingModel.fromJson(Map<String, dynamic> json) {
    return RecordingModel(
      id: json['id'] ?? '',
      orderId: json['orderId'] ?? '',
      localPath: json['localPath'] ?? '',
      remoteUrl: json['remoteUrl'] ?? '',
      duration: Duration(seconds: json['duration'] ?? 0),
      uploaded: json['uploaded'] ?? false,
      createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'orderId': orderId,
      'localPath': localPath,
      'remoteUrl': remoteUrl,
      'duration': duration.inSeconds,
      'uploaded': uploaded,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  RecordingModel copyWith({
    String? id,
    String? orderId,
    String? localPath,
    String? remoteUrl,
    Duration? duration,
    bool? uploaded,
    DateTime? createdAt,
  }) {
    return RecordingModel(
      id: id ?? this.id,
      orderId: orderId ?? this.orderId,
      localPath: localPath ?? this.localPath,
      remoteUrl: remoteUrl ?? this.remoteUrl,
      duration: duration ?? this.duration,
      uploaded: uploaded ?? this.uploaded,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  bool get hasVideo => localPath.isNotEmpty;

  bool get isUploaded => uploaded;

  @override
  String toString() {
    return 'RecordingModel(id: $id, orderId: $orderId)';
  }
}
