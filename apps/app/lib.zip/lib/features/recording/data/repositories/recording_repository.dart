import 'package:dio/dio.dart';

import '../../../../core/api/api_client.dart';
import '../models/recording_model.dart';

class RecordingRepository {
  final Dio _dio = ApiClient.dio;

  /// ------------------------------------------
  /// Start Recording Session
  /// ------------------------------------------

  Future<RecordingModel> startRecording(String orderId) async {
    try {
      final response = await _dio.post(
        "/recordings/start",
        data: {"orderId": orderId},
      );

      return RecordingModel.fromJson(response.data["data"]);
    } on DioException catch (e) {
      throw Exception(
        e.response?.data["message"] ?? "Unable to start recording.",
      );
    }
  }

  /// ------------------------------------------
  /// Stop Recording Session
  /// ------------------------------------------

  Future<RecordingModel> stopRecording(String recordingId) async {
    try {
      final response = await _dio.post("/recordings/$recordingId/stop");

      return RecordingModel.fromJson(response.data["data"]);
    } on DioException catch (e) {
      throw Exception(
        e.response?.data["message"] ?? "Unable to stop recording.",
      );
    }
  }

  /// ------------------------------------------
  /// Upload Recording
  /// ------------------------------------------

  Future<RecordingModel> uploadRecording({
    required String recordingId,
    required String filePath,
  }) async {
    try {
      final form = FormData.fromMap({
        "file": await MultipartFile.fromFile(filePath),
      });

      final response = await _dio.post(
        "/recordings/$recordingId/upload",
        data: form,
      );

      return RecordingModel.fromJson(response.data["data"]);
    } on DioException catch (e) {
      throw Exception(
        e.response?.data["message"] ?? "Unable to upload recording.",
      );
    }
  }

  /// ------------------------------------------
  /// Get Recording
  /// ------------------------------------------

  Future<RecordingModel> getRecording(String recordingId) async {
    try {
      final response = await _dio.get("/recordings/$recordingId");

      return RecordingModel.fromJson(response.data["data"]);
    } on DioException catch (e) {
      throw Exception(
        e.response?.data["message"] ?? "Unable to load recording.",
      );
    }
  }

  /// ------------------------------------------
  /// Delete Recording
  /// ------------------------------------------

  Future<void> deleteRecording(String recordingId) async {
    try {
      await _dio.delete("/recordings/$recordingId");
    } on DioException catch (e) {
      throw Exception(
        e.response?.data["message"] ?? "Unable to delete recording.",
      );
    }
  }
}
