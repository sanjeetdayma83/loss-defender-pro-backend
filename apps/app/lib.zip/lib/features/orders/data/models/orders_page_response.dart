import 'order_model.dart';

class OrdersPageResponse {
  final List<OrderModel> items;

  final int total;
  final int page;
  final int limit;

  final bool hasNext;
  final bool hasPrevious;

  OrdersPageResponse({
    required this.items,
    required this.total,
    required this.page,
    required this.limit,
    required this.hasNext,
    required this.hasPrevious,
  });

  factory OrdersPageResponse.fromJson(Map<String, dynamic> json) {
    final data = json["data"];

    return OrdersPageResponse(
      items: (data["items"] as List)
          .map((e) => OrderModel.fromJson(e))
          .toList(),
      total: data["total"],
      page: data["page"],
      limit: data["limit"],
      hasNext: data["hasNext"],
      hasPrevious: data["hasPrevious"],
    );
  }
}
