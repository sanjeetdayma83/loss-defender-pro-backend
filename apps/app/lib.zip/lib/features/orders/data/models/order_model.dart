class OrderModel {
  final String id;
  final String orderNumber;
  final String marketplaceOrderId;
  final String marketplace;
  final String customerName;
  final String customerPhone;

  final String status;
  final String packingStatus;
  final String verificationStatus;
  final String priority;

  final int expectedItemCount;
  final int verifiedItemCount;

  final String warehouseId;

  final DateTime createdAt;

  const OrderModel({
    required this.id,
    required this.orderNumber,
    required this.marketplaceOrderId,
    required this.marketplace,
    required this.customerName,
    required this.customerPhone,
    required this.status,
    required this.packingStatus,
    required this.verificationStatus,
    required this.priority,
    required this.expectedItemCount,
    required this.verifiedItemCount,
    required this.warehouseId,
    required this.createdAt,
  });

  factory OrderModel.fromJson(Map<String, dynamic> json) {
    return OrderModel(
      id: json["id"] ?? "",
      orderNumber: json["orderNumber"] ?? "",
      marketplaceOrderId: json["marketplaceOrderId"] ?? "",
      marketplace: json["marketplace"] ?? "",
      customerName: json["customerName"] ?? "",
      customerPhone: json["customerPhone"] ?? "",
      status: json["status"] ?? "",
      packingStatus: json["packingStatus"] ?? "",
      verificationStatus: json["verificationStatus"] ?? "",
      priority: json["priority"] ?? "",
      expectedItemCount: json["expectedItemCount"] ?? 0,
      verifiedItemCount: json["verifiedItemCount"] ?? 0,
      warehouseId: json["warehouseId"] ?? "",
      createdAt: DateTime.parse(json["createdAt"]),
    );
  }
}
