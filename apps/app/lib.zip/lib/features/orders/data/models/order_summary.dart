class OrderSummary {
  final String id;
  final String orderNumber;
  final String customer;
  final String status;
  final String marketplace;

  const OrderSummary({
    required this.id,
    required this.orderNumber,
    required this.customer,
    required this.status,
    required this.marketplace,
  });

  factory OrderSummary.fromJson(Map<String, dynamic> json) {
    return OrderSummary(
      id: json['id']?.toString() ?? '',
      orderNumber: json['orderNumber']?.toString() ?? '',
      customer: json['customerName']?.toString() ?? '',
      status: json['status']?.toString() ?? '',
      marketplace: json['marketplace']?.toString() ?? '',
    );
  }
}
