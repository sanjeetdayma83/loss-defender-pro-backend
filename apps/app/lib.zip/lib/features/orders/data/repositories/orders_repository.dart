import '../../../../core/api/api_client.dart';

import '../models/orders_page_response.dart';
import '../models/orders_query.dart';

class OrdersRepository {
  Future<OrdersPageResponse> getOrders(OrdersQuery query) async {
    final response = await ApiClient.dio.get(
      "/orders",
      queryParameters: query.toQuery(),
    );

    return OrdersPageResponse.fromJson(response.data);
  }

  Future<void> startPacking(String id) =>
      ApiClient.dio.post("/orders/$id/start-packing");

  Future<void> startRecording(String id) =>
      ApiClient.dio.post("/orders/$id/start-recording");

  Future<void> startVerification(String id) =>
      ApiClient.dio.post("/orders/$id/start-verification");

  Future<void> readyToShip(String id) =>
      ApiClient.dio.post("/orders/$id/ready-to-ship");

  Future<void> ship(String id) => ApiClient.dio.post("/orders/$id/ship");
}
