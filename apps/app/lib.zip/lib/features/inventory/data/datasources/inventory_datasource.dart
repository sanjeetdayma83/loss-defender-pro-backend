class InventoryDatasource {}
