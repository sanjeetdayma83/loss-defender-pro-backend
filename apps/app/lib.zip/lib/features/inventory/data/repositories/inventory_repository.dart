class InventoryRepository {}
