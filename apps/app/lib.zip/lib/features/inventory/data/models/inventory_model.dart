class InventoryModel {}
