class InventoryController {}
