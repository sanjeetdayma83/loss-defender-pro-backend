class InventoryProvider {}
