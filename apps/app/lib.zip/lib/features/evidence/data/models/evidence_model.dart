class EvidenceModel {
  final String id;
  final String orderId;
  final String videoUrl;
  final String thumbnailUrl;
  final int duration;
  final int fileSize;
  final DateTime uploadedAt;
  final String uploadedBy;

  const EvidenceModel({
    required this.id,
    required this.orderId,
    required this.videoUrl,
    required this.thumbnailUrl,
    required this.duration,
    required this.fileSize,
    required this.uploadedAt,
    required this.uploadedBy,
  });

  factory EvidenceModel.fromJson(Map<String, dynamic> json) {
    return EvidenceModel(
      id: json["id"] ?? "",
      orderId: json["orderId"] ?? "",
      videoUrl: json["videoUrl"] ?? "",
      thumbnailUrl: json["thumbnailUrl"] ?? "",
      duration: json["duration"] ?? 0,
      fileSize: json["fileSize"] ?? 0,
      uploadedAt: DateTime.tryParse(json["uploadedAt"] ?? "") ?? DateTime.now(),
      uploadedBy: json["uploadedBy"] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "orderId": orderId,
      "videoUrl": videoUrl,
      "thumbnailUrl": thumbnailUrl,
      "duration": duration,
      "fileSize": fileSize,
      "uploadedAt": uploadedAt.toIso8601String(),
      "uploadedBy": uploadedBy,
    };
  }
}
