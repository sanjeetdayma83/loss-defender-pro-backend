import '../../../../core/api/api_client.dart';
import '../models/evidence_model.dart';
import 'package:dio/dio.dart';

class EvidenceRepository {
  Future<EvidenceModel> getEvidence(String orderId) async {
    final response = await ApiClient.dio.get("/orders/$orderId/evidence");

    return EvidenceModel.fromJson(response.data["data"]);
  }

  Future<void> uploadEvidence({
    required String orderId,
    required String filePath,
  }) async {
    final formData = FormData.fromMap({
      "video": await MultipartFile.fromFile(filePath),
    });

    await ApiClient.dio.post("/orders/$orderId/evidence", data: formData);
  }

  Future<void> deleteEvidence(String evidenceId) async {
    await ApiClient.dio.delete("/evidence/$evidenceId");
  }
}
